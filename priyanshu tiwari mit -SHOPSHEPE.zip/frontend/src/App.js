import React from "react";
function App() {
  return <h1>ShopShere Running</h1>;
}
export default App;
